# Specks AI — Website starter

## Features
- Camera requests permission on page load and then shows live video, no Scan button.
- Switch rear/front camera.
- Optional automatic AI recognition every ~0.4 seconds (only one request at a time; actual recognition latency depends on backend), only when a compatible HTTPS backend is supplied.
- Demo nutrition is **sample data only**, not camera recognition.
- PWA manifest and simple service worker.

## Deploy from phone
Upload the contents of this folder to an HTTPS static hosting provider (e.g., Netlify Drop, Cloudflare Pages, GitHub Pages). Open the deployed HTTPS URL in Chrome, allow camera permission, and optionally add a compatible HTTPS AI endpoint.

## AI backend contract
POST multipart/form-data with field `image` (JPEG file). Return JSON such as:
```
{"food":"Idli","portion":"Estimated 2 medium idlis","calories":116,"carbs_g":24,"protein_g":4,"fiber_g":1,"gi":null,"gl":null}
```
Numbers are illustrative, not authoritative. Server should implement authentication, rate limits, CORS for the site origin, secure API key handling, and image analysis. Never embed an AI API key in browser JavaScript. GI is not directly measurable from a photo; GL requires estimated GI and available carbohydrates. The client intentionally displays unknown values as em dashes.

## Notes
Browsers may require a camera permission tap and may suspend camera capture in the background. HTTPS is required except localhost. Recognition depends on the server and network, not just these static files.
